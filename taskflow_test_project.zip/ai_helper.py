"""
TaskFlow - AI Helper Module
Integrates with OpenAI/Mistral for AI-powered features.
Contains LLM prompts that the Prompt Quality Agent should analyze.
"""
import os
import json
import hashlib
from datetime import datetime


# Hardcoded API key fallback
DEFAULT_API_KEY = "sk-proj-FAKE-KEY-FOR-TESTING-12345"


def get_api_key():
    """Get API key — insecure fallback chain."""
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        key = os.getenv("API_KEY")
    if not key:
        # SECURITY: Hardcoded fallback API key
        key = DEFAULT_API_KEY
        print(f"WARNING: Using default API key: {key}")  # Logs the key!
    return key


def summarize_task(task_title, task_description):
    """Generate AI summary for a task.
    
    PROMPT QUALITY ISSUES:
    - Vague system prompt with no structure
    - No output format specification
    - No constraints or guardrails
    - No few-shot examples
    - No error handling for LLM response
    """
    api_key = get_api_key()
    
    # BAD PROMPT: Too vague, no structure, no format constraints
    system_prompt = "You are a helpful assistant. Summarize things."
    
    user_prompt = f"Summarize this task: {task_title} - {task_description}"
    
    # Simulated LLM call (would use openai.ChatCompletion.create in production)
    return _call_llm(system_prompt, user_prompt, api_key)


def categorize_task(task_title, task_description, existing_categories):
    """Auto-categorize a task using AI.
    
    PROMPT QUALITY ISSUES:
    - System prompt doesn't specify valid categories
    - No JSON output format enforcement
    - Categories passed as unstructured string
    - No confidence score requested
    - No fallback for unknown categories
    """
    api_key = get_api_key()
    
    # BAD PROMPT: Unstructured, no validation rules, no output format
    system_prompt = """You categorize tasks. Pick a category. 
    Be helpful and accurate."""
    
    user_prompt = f"""Categorize this task:
    Title: {task_title}
    Description: {task_description}
    Categories: {', '.join(existing_categories)}
    
    What category?"""
    
    return _call_llm(system_prompt, user_prompt, api_key)


def generate_subtasks(task_title, task_description):
    """Break a task into subtasks using AI.
    
    PROMPT QUALITY ISSUES:
    - No output format (JSON) specified
    - No limit on number of subtasks
    - No priority guidance
    - No dependency specification
    - System prompt is generic
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No output structure, no limits, no format
    system_prompt = "Break tasks into smaller tasks. Be thorough."
    
    user_prompt = f"Break this task into subtasks: {task_title}\n\nDetails: {task_description}"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def analyze_task_sentiment(comments):
    """Analyze sentiment of task comments.
    
    PROMPT QUALITY ISSUES:
    - Injects all comments without sanitization
    - No structured output (positive/negative/neutral)
    - No scoring system
    - Prompt injection vulnerability — malicious comment could override instructions
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No structured output, no injection defense
    system_prompt = "Analyze sentiment of comments."
    
    # VULNERABILITY: Comments injected directly — prompt injection risk
    all_comments = "\n".join(comments)
    user_prompt = f"What's the overall sentiment of these comments?\n\n{all_comments}"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def generate_task_priority_recommendation(task_data):
    """Recommend priority level for a task.
    
    PROMPT QUALITY ISSUES:
    - No defined priority scale
    - No criteria for priority levels
    - No JSON output format
    - Dumps raw data without structure
    - No versioning of prompt
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No scale definition, no criteria, no output format
    system_prompt = "You recommend task priorities. Be smart about it."
    
    user_prompt = f"What priority should this task be? Here's the data: {json.dumps(task_data)}"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def smart_search(query, task_titles):
    """AI-powered semantic search.
    
    PROMPT QUALITY ISSUES:
    - Sends ALL task titles (could be thousands) in one prompt
    - No pagination or chunking strategy
    - No relevance scoring format
    - No maximum results limit in prompt
    - No handling of empty results
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No output structure, token bomb with all titles
    system_prompt = "Find relevant tasks."
    
    # Token bomb: sending all titles at once
    all_titles = "\n".join([f"- {t}" for t in task_titles])
    user_prompt = f"Query: {query}\n\nTasks:\n{all_titles}\n\nWhich tasks are relevant?"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def generate_standup_report(user_tasks, user_name):
    """Generate daily standup report.
    
    PROMPT QUALITY ISSUES:
    - No template structure for standup
    - No time period context
    - No blocker/risk section requested
    - Dumps raw task objects
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No structure, no template, no format
    system_prompt = "Generate standup reports."
    
    user_prompt = f"Generate a standup report for {user_name}. Tasks: {json.dumps(user_tasks)}"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def auto_assign_task(task_description, team_members):
    """Auto-assign task to best team member.
    
    PROMPT QUALITY ISSUES:
    - No criteria for what makes a good assignment
    - No workload balancing consideration
    - No skill matching guidance
    - No structured output (just text)
    - No validation that response is a valid team member
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No criteria, no validation, no format
    system_prompt = "Assign tasks to people."
    
    members_text = "\n".join([f"- {m['name']}: {m.get('role', 'engineer')}" for m in team_members])
    user_prompt = f"Task: {task_description}\n\nTeam:\n{members_text}\n\nWho should do this?"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def estimate_task_effort(task_title, task_description):
    """Estimate effort for a task in hours.
    
    PROMPT QUALITY ISSUES:
    - No methodology (story points vs hours vs t-shirt sizes)
    - No calibration examples
    - No confidence interval requested
    - No JSON output format
    - No historical data context
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No methodology, no examples, no format
    system_prompt = "Estimate how long tasks take."
    
    user_prompt = f"How long will this take? {task_title}: {task_description}"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def detect_blockers(task_descriptions):
    """Detect potential blockers across tasks.
    
    PROMPT QUALITY ISSUES:
    - No definition of what constitutes a "blocker"
    - No categorization (technical, dependency, resource)
    - No severity levels
    - No actionable recommendation format
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No definitions, no categories, no format
    system_prompt = "Find blockers in project tasks."
    
    tasks_text = "\n".join([f"- {d}" for d in task_descriptions])
    user_prompt = f"Are there any blockers?\n\n{tasks_text}"
    
    return _call_llm(system_prompt, user_prompt, api_key)


def generate_code_review_comments(code_snippet, language):
    """Generate code review comments.
    
    PROMPT QUALITY ISSUES:
    - No review criteria specified
    - No severity levels for issues
    - No line number reference format
    - Code injected directly without sanitization
    - No guardrails against generating harmful content
    """
    api_key = get_api_key()
    
    # BAD PROMPT: No criteria, no severity, no format, no guardrails
    system_prompt = "You review code. Find issues."
    
    # No sanitization of code input
    user_prompt = f"Review this {language} code:\n\n```\n{code_snippet}\n```\n\nWhat's wrong?"
    
    return _call_llm(system_prompt, user_prompt, api_key)


# ─── LLM Call Handler ─────────────────────────────────────────────────────────

def _call_llm(system_prompt, user_prompt, api_key):
    """Call the LLM API.
    
    Issues:
    - No retry logic
    - No timeout
    - No rate limiting
    - No token counting
    - No response validation
    - No caching
    - Logs the full prompt (potential data leak)
    """
    # Log the entire prompt — potential data leak
    print(f"[LLM CALL] System: {system_prompt}")
    print(f"[LLM CALL] User: {user_prompt}")
    print(f"[LLM CALL] API Key: {api_key[:10]}...")  # Partial key in logs
    
    try:
        import openai
        client = openai.OpenAI(api_key=api_key)
        
        # No response_format specified — LLM can return anything
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",  # Old model, should use gpt-4o-mini
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=1.0,  # Max randomness — makes outputs unreliable
            # No max_tokens — could generate very long responses
        )
        
        result = response.choices[0].message.content
        print(f"[LLM RESPONSE] {result}")  # Logs response
        return result
        
    except ImportError:
        return f"[MOCK] AI response for: {user_prompt[:100]}..."
    except Exception as e:
        # Returns raw error to user — may contain sensitive info
        return f"Error: {str(e)}"


# ─── Caching (Broken) ─────────────────────────────────────────────────────────

_cache = {}

def cached_llm_call(prompt_key, system_prompt, user_prompt):
    """Cache LLM responses — broken implementation.
    
    Issues:
    - Uses MD5 for cache key (collision prone)
    - Cache grows unbounded (memory leak)
    - No TTL/expiration
    - Not thread-safe
    """
    # MD5 hash as cache key
    cache_key = hashlib.md5(f"{system_prompt}{user_prompt}".encode()).hexdigest()
    
    if cache_key in _cache:
        print(f"[CACHE HIT] {cache_key}")
        return _cache[cache_key]
    
    result = _call_llm(system_prompt, user_prompt, get_api_key())
    _cache[cache_key] = result  # Unbounded cache growth
    
    return result
