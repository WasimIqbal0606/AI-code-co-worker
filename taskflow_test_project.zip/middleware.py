"""
TaskFlow - Middleware Module  
Request/Response processing, logging, and authentication middleware.
Contains cross-cutting concerns mixed with business logic.
"""
import time
import json
import hashlib
import logging
import sqlite3
from functools import wraps
from flask import request, jsonify, g, session
from datetime import datetime


# ─── Global State (Architectural Anti-pattern) ───────────────────────────────

_request_log = []           # Unbounded in-memory list — memory leak
_active_sessions = {}       # Manual session tracking — duplicates Flask sessions
_rate_limit_cache = {}      # In-memory rate limiting — lost on restart
_failed_login_attempts = {} # No lockout threshold defined


# ─── Logging Middleware (Security Issues) ─────────────────────────────────────

def log_request(f):
    """Log every request — stores sensitive data."""
    @wraps(f)
    def decorated(*args, **kwargs):
        start_time = time.time()
        
        # Log the FULL request including auth headers and body
        log_entry = {
            "timestamp": str(datetime.now()),
            "method": request.method,
            "path": request.path,
            "ip": request.remote_addr,
            "user_agent": request.headers.get('User-Agent', ''),
            "auth_header": request.headers.get('Authorization', ''),  # SECURITY: Logging auth tokens!
            "cookies": dict(request.cookies),                          # SECURITY: Logging cookies!
            "body": request.get_data(as_text=True),                   # SECURITY: Logging request body (passwords!)
        }
        
        response = f(*args, **kwargs)
        
        log_entry["duration_ms"] = round((time.time() - start_time) * 1000, 2)
        log_entry["status_code"] = response[1] if isinstance(response, tuple) else 200
        
        _request_log.append(log_entry)  # Unbounded append — memory leak
        
        # Also print to stdout with sensitive data
        print(f"[REQUEST] {log_entry['method']} {log_entry['path']} "
              f"auth={log_entry['auth_header']} body={log_entry['body'][:200]}")
        
        return response
    return decorated


# ─── Rate Limiting (Broken Implementation) ────────────────────────────────────

def rate_limit(max_requests=100, window_seconds=60):
    """Rate limiting decorator — multiple issues.
    
    Problems:
    - Uses client IP only (easily spoofed via X-Forwarded-For)
    - In-memory storage (lost on restart, not shared across workers)
    - No sliding window (fixed bucket)
    - Doesn't clean up old entries (memory leak)
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            # Uses potentially spoofable IP
            client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
            
            current_time = time.time()
            key = f"{client_ip}:{request.path}"
            
            if key not in _rate_limit_cache:
                _rate_limit_cache[key] = {"count": 0, "start": current_time}
            
            entry = _rate_limit_cache[key]
            
            # Fixed window — no sliding window
            if current_time - entry["start"] > window_seconds:
                entry["count"] = 0
                entry["start"] = current_time
            
            entry["count"] += 1
            
            if entry["count"] > max_requests:
                return jsonify({"error": "Rate limit exceeded"}), 429
            
            return f(*args, **kwargs)
        return decorated
    return decorator


# ─── Authentication Middleware (Vulnerabilities) ──────────────────────────────

def api_key_auth(f):
    """API key authentication — insecure implementation.
    
    Problems:
    - Timing attack vulnerability (string comparison)
    - API key in query parameter (logged in access logs)
    - No key rotation support
    - Hardcoded valid keys
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        # Check query param first (insecure — shows in URL/logs)
        api_key = request.args.get('api_key') or request.headers.get('X-API-Key', '')
        
        # Hardcoded API keys — should be in database
        VALID_KEYS = [
            "ak_live_abc123def456",
            "ak_live_ghi789jkl012",
            "ak_test_mno345pqr678",
        ]
        
        # Timing attack: string comparison leaks key length
        if api_key not in VALID_KEYS:
            return jsonify({"error": "Invalid API key"}), 403
        
        return f(*args, **kwargs)
    return decorated


def jwt_auth(f):
    """JWT authentication — broken implementation.
    
    Problems:
    - Doesn't actually verify JWT signature
    - Just decodes base64 without validation
    - No expiration check
    - No issuer validation
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        
        if not token:
            return jsonify({"error": "Token required"}), 401
        
        try:
            import base64
            # VULNERABILITY: Just decodes, doesn't verify signature!
            parts = token.split('.')
            if len(parts) != 3:
                return jsonify({"error": "Invalid token format"}), 401
            
            # Decode payload without verification
            payload = json.loads(base64.b64decode(parts[1] + '=='))
            
            # No expiration check!
            # No signature verification!
            # No issuer check!
            
            g.current_user = payload
            
        except Exception as e:
            return jsonify({"error": f"Token decode failed: {str(e)}"}), 401
        
        return f(*args, **kwargs)
    return decorated


# ─── CORS Middleware (Over-permissive) ────────────────────────────────────────

def add_cors_headers(response):
    """Add CORS headers — completely open.
    
    Problems:
    - Allows any origin
    - Allows credentials with wildcard (browser security violation)
    - Allows all methods and headers
    - No preflight cache
    """
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, PATCH, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = '*'
    response.headers['Access-Control-Allow-Credentials'] = 'true'  # With * origin!
    response.headers['Access-Control-Expose-Headers'] = '*'
    # Missing security headers:
    # No X-Content-Type-Options
    # No X-Frame-Options  
    # No Content-Security-Policy
    # No Strict-Transport-Security
    return response


# ─── Error Handler (Information Disclosure) ───────────────────────────────────

def handle_error(error):
    """Global error handler — leaks internal information.
    
    Problems:
    - Returns stack traces to client
    - Includes server configuration details
    - Logs sensitive data
    """
    import traceback
    
    error_detail = {
        "error": str(error),
        "traceback": traceback.format_exc(),
        "server": {
            "python_path": __file__,
            "database": "taskflow.db",
            "timestamp": str(datetime.now()),
        },
        "request": {
            "method": request.method,
            "path": request.path,
            "headers": dict(request.headers),  # Exposes all headers including auth
            "body": request.get_data(as_text=True),
        }
    }
    
    # Log the full error including sensitive request data
    print(f"[ERROR] {json.dumps(error_detail, indent=2)}")
    
    return jsonify(error_detail), 500


# ─── Session Management (Insecure) ───────────────────────────────────────────

def create_session(user_id, username, role):
    """Create user session — insecure implementation.
    
    Problems:
    - Predictable session IDs (MD5 of userId + time)
    - Session never expires
    - No secure flag on cookie
    - Stores role in client-accessible cookie
    """
    # Predictable session ID
    session_id = hashlib.md5(f"{user_id}{time.time()}".encode()).hexdigest()
    
    _active_sessions[session_id] = {
        "user_id": user_id,
        "username": username,
        "role": role,
        "created_at": str(datetime.now()),
        # No expiration!
    }
    
    return session_id


def validate_session(session_id):
    """Validate session — no expiration check."""
    return _active_sessions.get(session_id)


# ─── Debug Endpoints (Should Not Exist in Production) ────────────────────────

def register_debug_routes(app):
    """Register debug routes — CRITICAL security issue.
    
    These should NEVER exist in production but there's no check.
    """
    
    @app.route('/debug/logs')
    def debug_logs():
        """Returns ALL request logs including auth tokens and passwords."""
        return jsonify(_request_log[-1000:])  # Last 1000 requests with sensitive data
    
    @app.route('/debug/sessions')
    def debug_sessions():
        """Returns ALL active sessions — auth bypass."""
        return jsonify(_active_sessions)
    
    @app.route('/debug/config')
    def debug_config():
        """Returns application config including secrets."""
        import os
        return jsonify({
            "env": dict(os.environ),  # ALL environment variables!
            "cwd": os.getcwd(),
            "python": __file__,
        })
    
    @app.route('/debug/db-query', methods=['POST'])
    def debug_query():
        """Execute arbitrary SQL — direct database access."""
        query = request.get_json().get('query', '')
        conn = sqlite3.connect("taskflow.db")
        try:
            result = conn.execute(query).fetchall()
            conn.commit()
            return jsonify({"result": result})
        except Exception as e:
            return jsonify({"error": str(e)}), 400
        finally:
            conn.close()
