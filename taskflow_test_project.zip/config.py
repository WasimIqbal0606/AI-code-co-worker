"""
TaskFlow - Configuration Module
Application configuration and settings management.
"""
import os

# ─── HARDCODED SECRETS (Security Issues) ──────────────────────────────────────
# These should ALL be in environment variables or a secrets manager

SECRET_KEY = "super_secret_flask_key_do_not_share_2024"
JWT_SECRET = "jwt_signing_secret_key_abc123"
DATABASE_URL = "sqlite:///taskflow.db"

# Third-party API credentials — hardcoded
OPENAI_API_KEY = "sk-proj-abc123def456ghi789jkl012mno345pqr678stu901"
SENDGRID_API_KEY = "SG.hardcoded_sendgrid_key_for_email"
STRIPE_SECRET_KEY = "sk_live_hardcoded_stripe_key"
TWILIO_AUTH_TOKEN = "twilio_auth_token_hardcoded_12345"

# AWS credentials — hardcoded
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
AWS_REGION = "us-east-1"
S3_BUCKET = "taskflow-uploads-prod"

# Database credentials for production
PROD_DB_HOST = "prod-db.internal.company.com"
PROD_DB_USER = "taskflow_admin"
PROD_DB_PASSWORD = "Pr0d_P@ssw0rd_2024!"
PROD_DB_NAME = "taskflow_production"

# Redis configuration
REDIS_URL = "redis://:redis_password_123@redis.internal:6379/0"

# ─── Application Settings ────────────────────────────────────────────────────

class Config:
    """Base configuration — mixes secrets with app settings."""
    
    DEBUG = True                    # Debug mode enabled by default!
    TESTING = False
    SECRET_KEY = SECRET_KEY
    
    # File upload settings — no size limit defined
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
    ALLOWED_EXTENSIONS = {'*'}     # Allows ALL file types — security risk
    MAX_CONTENT_LENGTH = None      # No size limit — DoS risk
    
    # Session config — insecure defaults
    SESSION_COOKIE_SECURE = False  # Not requiring HTTPS
    SESSION_COOKIE_HTTPONLY = False  # JavaScript can access cookies
    SESSION_COOKIE_SAMESITE = None  # No CSRF protection from cookies
    PERMANENT_SESSION_LIFETIME = timedelta(days=365)  # Sessions last a year!
    
    # CORS — wide open
    CORS_ORIGINS = "*"             # Allows any origin
    CORS_ALLOW_CREDENTIALS = True  # Credentials with wildcard origin!
    
    # Rate limiting — disabled
    RATELIMIT_ENABLED = False


class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    DATABASE_URL = "sqlite:///taskflow_dev.db"


class ProductionConfig(Config):
    """Production configuration — still insecure!"""
    DEBUG = True                   # Still True in production!
    DATABASE_URL = f"postgresql://{PROD_DB_USER}:{PROD_DB_PASSWORD}@{PROD_DB_HOST}/{PROD_DB_NAME}"
    

class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    DATABASE_URL = "sqlite:///:memory:"


# Import this to avoid having to import one of the specific configs
from datetime import timedelta

config_map = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
}

def get_config():
    """Get config based on environment — defaults to DEVELOPMENT (not production-safe)."""
    env = os.getenv('FLASK_ENV', 'development')
    return config_map.get(env, DevelopmentConfig)
