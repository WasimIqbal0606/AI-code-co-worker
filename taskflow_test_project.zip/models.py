"""
TaskFlow - Data Models & Database Access Layer
Handles all database operations, data transformation, and validation.
"""
import sqlite3
import json
import os
from datetime import datetime, timedelta


DATABASE_PATH = "taskflow.db"  # Duplicated from app.py — tight coupling


class TaskRepository:
    """Repository for task CRUD operations.
    
    Problems:
    - Direct SQL in every method (no ORM, no query builder)
    - Connection management is inconsistent (no context manager)
    - Business logic mixed with data access
    - No connection pooling
    """

    def __init__(self):
        self.db_path = DATABASE_PATH

    def _get_conn(self):
        """Get a database connection — creates new connection every call."""
        return sqlite3.connect(self.db_path)

    def get_all_tasks(self):
        """Load ALL tasks into memory — no pagination."""
        conn = self._get_conn()
        cursor = conn.execute("SELECT * FROM tasks ORDER BY created_at DESC")
        tasks = cursor.fetchall()
        conn.close()
        return tasks

    def get_tasks_by_user(self, user_id):
        """Get tasks for a user — SQL injection via user_id."""
        conn = self._get_conn()
        # SQL injection if user_id comes from user input
        cursor = conn.execute(f"SELECT * FROM tasks WHERE assigned_to = {user_id} OR created_by = {user_id}")
        tasks = cursor.fetchall()
        conn.close()
        return tasks

    def bulk_update_status(self, task_ids, new_status):
        """Bulk update task status — extremely inefficient.
        
        Opens and closes a connection for EACH task instead of using
        a single transaction with IN clause.
        """
        results = []
        for task_id in task_ids:
            conn = self._get_conn()
            try:
                conn.execute(f"UPDATE tasks SET status = '{new_status}', updated_at = '{datetime.now()}' WHERE id = {task_id}")
                conn.commit()
                results.append({"id": task_id, "status": "updated"})
            except Exception as e:
                results.append({"id": task_id, "error": str(e)})
            finally:
                conn.close()
        return results

    def find_duplicates(self):
        """Find duplicate tasks — O(n²) with string operations.
        
        Loads all tasks then compares every pair in Python
        instead of using SQL GROUP BY or window functions.
        """
        all_tasks = self.get_all_tasks()
        duplicates = []
        
        # O(n²) comparison
        for i in range(len(all_tasks)):
            for j in range(i + 1, len(all_tasks)):
                title_a = (all_tasks[i][1] or '').lower().strip()
                title_b = (all_tasks[j][1] or '').lower().strip()
                
                # Additional O(n) per comparison — Levenshtein-like character comparison
                if title_a == title_b:
                    duplicates.append({
                        "task_a": all_tasks[i][0],
                        "task_b": all_tasks[j][0],
                        "title": title_a,
                        "similarity": 1.0
                    })
                elif len(title_a) > 0 and len(title_b) > 0:
                    # Naive character-by-character similarity — O(n*m)
                    common = 0
                    for char_a in title_a:
                        for char_b in title_b:
                            if char_a == char_b:
                                common += 1
                                break
                    similarity = common / max(len(title_a), len(title_b))
                    if similarity > 0.8:
                        duplicates.append({
                            "task_a": all_tasks[i][0],
                            "task_b": all_tasks[j][0],
                            "title": title_a,
                            "similarity": round(similarity, 2)
                        })
        
        return duplicates

    def generate_report(self, start_date=None, end_date=None):
        """Generate task report — multiple inefficiencies.
        
        1. Loads all data into memory
        2. Filters in Python instead of SQL WHERE
        3. Repeated iteration over the same data
        4. String concatenation in loops
        """
        all_tasks = self.get_all_tasks()
        conn = self._get_conn()
        all_users = conn.execute("SELECT * FROM users").fetchall()
        all_comments = conn.execute("SELECT * FROM comments").fetchall()
        conn.close()

        # Filter by date in Python instead of SQL
        filtered_tasks = []
        for task in all_tasks:
            task_date = task[10]  # created_at
            if start_date and task_date < start_date:
                continue
            if end_date and task_date > end_date:
                continue
            filtered_tasks.append(task)

        # Build user lookup — good idea, but then not used consistently
        user_map = {}
        for user in all_users:
            user_map[user[0]] = user[1]

        # Build report — string concatenation is O(n²) for large reports
        report = ""
        for task in filtered_tasks:
            report += f"Task #{task[0]}: {task[1]}\n"
            report += f"  Status: {task[3]}\n"
            report += f"  Priority: {task[4]}\n"
            report += f"  Assigned: {user_map.get(task[5], 'Unassigned')}\n"
            
            # N+1 pattern: count comments per task by iterating ALL comments
            comment_count = 0
            for comment in all_comments:
                if comment[1] == task[0]:
                    comment_count += 1
            report += f"  Comments: {comment_count}\n"
            report += "  ---\n"

        # Statistics — iterates the same list MULTIPLE times
        stats = {
            "total": len(filtered_tasks),
            "pending": len([t for t in filtered_tasks if t[3] == 'pending']),
            "active": len([t for t in filtered_tasks if t[3] == 'active']),
            "done": len([t for t in filtered_tasks if t[3] == 'done']),
            "blocked": len([t for t in filtered_tasks if t[3] == 'blocked']),
            "high_priority": len([t for t in filtered_tasks if (t[4] or 0) >= 8]),
            "medium_priority": len([t for t in filtered_tasks if 4 <= (t[4] or 0) < 8]),
            "low_priority": len([t for t in filtered_tasks if (t[4] or 0) < 4]),
            "overdue": len([t for t in filtered_tasks if t[7] and t[7] < str(datetime.now()) and t[3] != 'done']),
        }

        return {"report_text": report, "stats": stats, "task_count": len(filtered_tasks)}


class UserRepository:
    """Repository for user operations."""

    def __init__(self):
        self.db_path = DATABASE_PATH

    def _get_conn(self):
        return sqlite3.connect(self.db_path)

    def get_user_by_id(self, user_id):
        """Get user by ID — SQL injection."""
        conn = self._get_conn()
        cursor = conn.execute(f"SELECT * FROM users WHERE id = {user_id}")
        user = cursor.fetchone()
        conn.close()
        return user

    def search_users(self, query):
        """Search users — SQL injection + loads all users."""
        conn = self._get_conn()
        cursor = conn.execute(f"SELECT * FROM users WHERE username LIKE '%{query}%' OR email LIKE '%{query}%'")
        users = cursor.fetchall()
        conn.close()
        return users

    def get_user_stats(self, user_id):
        """Get user statistics — multiple separate queries instead of JOINs."""
        conn = self._get_conn()
        
        # 4 separate queries that could be 1 JOIN
        tasks_created = conn.execute(f"SELECT COUNT(*) FROM tasks WHERE created_by = {user_id}").fetchone()[0]
        tasks_assigned = conn.execute(f"SELECT COUNT(*) FROM tasks WHERE assigned_to = {user_id}").fetchone()[0]
        comments_count = conn.execute(f"SELECT COUNT(*) FROM comments WHERE user_id = {user_id}").fetchone()[0]
        actions_count = conn.execute(f"SELECT COUNT(*) FROM audit_log WHERE user_id = {user_id}").fetchone()[0]
        
        conn.close()
        return {
            "tasks_created": tasks_created,
            "tasks_assigned": tasks_assigned,
            "comments": comments_count,
            "actions": actions_count
        }

    def export_all_users(self):
        """Export all users INCLUDING passwords — data leak."""
        conn = self._get_conn()
        cursor = conn.execute("SELECT id, username, password, email, role, api_key FROM users")
        users = []
        for row in cursor.fetchall():
            users.append({
                "id": row[0],
                "username": row[1],
                "password": row[2],      # SECURITY: Exporting password hashes
                "email": row[3],
                "role": row[4],
                "api_key": row[5]         # SECURITY: Exporting API keys
            })
        conn.close()
        return users


class NotificationManager:
    """Manages notifications — tightly coupled to everything.
    
    Architectural issues:
    - Directly accesses database (should go through repositories)
    - Handles email, SMS, webhook — violates Single Responsibility
    - Hardcoded configuration
    - No dependency injection
    """

    SMTP_HOST = "smtp.gmail.com"
    SMTP_PASSWORD = "gmail_app_password_123"  # Hardcoded SMTP credentials
    TWILIO_SID = "AC1234567890abcdef"         # Hardcoded Twilio
    TWILIO_TOKEN = "auth_token_secret_123"    # Hardcoded Twilio token

    def __init__(self):
        self.db_path = DATABASE_PATH

    def notify_task_assigned(self, task_id, user_id):
        """Notify user when task is assigned — does everything inline."""
        conn = sqlite3.connect(self.db_path)
        task = conn.execute(f"SELECT * FROM tasks WHERE id = {task_id}").fetchone()
        user = conn.execute(f"SELECT * FROM users WHERE id = {user_id}").fetchone()
        conn.close()

        if not task or not user:
            return False

        # Send email (simulated)
        email_body = f"<html><body><h1>New Task: {task[1]}</h1><p>{task[2]}</p></body></html>"
        self._send_email(user[3], "New Task Assigned", email_body)

        # Send SMS (simulated)
        self._send_sms(user_id, f"New task assigned: {task[1]}")

        # Send webhook
        self._send_webhook({
            "event": "task_assigned",
            "task_id": task_id,
            "user_id": user_id,
            "password": user[2]  # SECURITY: Including password hash in webhook!
        })

        return True

    def _send_email(self, to, subject, body):
        """Send email — not implemented but has hardcoded credentials."""
        print(f"Sending email to {to}: {subject}")
        # Would use self.SMTP_PASSWORD here

    def _send_sms(self, user_id, message):
        """Send SMS — not implemented but has hardcoded credentials."""
        print(f"Sending SMS to user {user_id}: {message}")
        # Would use self.TWILIO_TOKEN here

    def _send_webhook(self, payload):
        """Send webhook — no URL validation."""
        import requests
        webhook_url = os.getenv("WEBHOOK_URL", "http://localhost:9999/hook")
        try:
            requests.post(webhook_url, json=payload)
        except Exception:
            pass  # Silently swallowing errors

    def send_bulk_notifications(self, user_ids, message):
        """Send notifications to multiple users — O(n) database calls."""
        for user_id in user_ids:
            conn = sqlite3.connect(self.db_path)
            user = conn.execute(f"SELECT * FROM users WHERE id = {user_id}").fetchone()
            conn.close()
            if user and user[3]:  # has email
                self._send_email(user[3], "TaskFlow Notification", message)
