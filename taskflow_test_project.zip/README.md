# TaskFlow — Task Management API

A lightweight task management REST API built with Flask and SQLite.

## Features

- User registration and authentication
- Task CRUD operations with filtering and search
- Comment system on tasks
- AI-powered task analysis (summarization, categorization, subtask generation)
- CSV import/export
- Sprint analytics and burndown charts
- Team velocity tracking
- Webhook notifications

## Quick Start

```bash
pip install -r requirements.txt
python app.py
```

Server runs at http://localhost:5000

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /register | Register a new user |
| POST | /login | Login |
| GET | /tasks | Get all tasks |
| POST | /tasks | Create a task |
| PUT | /tasks/:id | Update a task |
| DELETE | /tasks/:id | Delete a task |
| GET | /tasks/:id/comments | Get task comments |
| POST | /tasks/:id/comments | Add a comment |
| GET | /dashboard | View dashboard |
| GET | /analytics/task-summary | Task analytics |
| GET | /search?q=query | Search tasks |
| GET | /reports/export | Export report |
| POST | /upload | Upload attachment |
| POST | /webhook/notify | Send webhook |

## Tech Stack

- Python 3.11+
- Flask
- SQLite
- OpenAI GPT for AI features
