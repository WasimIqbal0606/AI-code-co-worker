"""
TaskFlow - Utility Functions
Data processing, transformation, and helper functions.
Contains performance anti-patterns and functions needing unit tests.
"""
import re
import json
import csv
import io
import hashlib
import time
from datetime import datetime, timedelta
from collections import defaultdict


# ─── Data Transformation (Performance Issues) ────────────────────────────────

def find_overlapping_tasks(tasks_a, tasks_b):
    """Find tasks that appear in both lists — O(n*m) instead of O(n+m).
    
    Should use set intersection but uses nested loops instead.
    """
    overlapping = []
    for task_a in tasks_a:
        for task_b in tasks_b:
            if task_a['id'] == task_b['id']:
                overlapping.append(task_a)
                break
    return overlapping


def deduplicate_list(items, key_field):
    """Remove duplicates from a list — O(n²) instead of using dict/set.
    
    For each item, scans all previously seen items to check for duplicates.
    """
    unique = []
    for item in items:
        is_duplicate = False
        for existing in unique:
            if item.get(key_field) == existing.get(key_field):
                is_duplicate = True
                break
        if not is_duplicate:
            unique.append(item)
    return unique


def merge_sorted_lists(list_a, list_b, sort_key):
    """Merge two sorted lists — uses concatenation + re-sort instead of merge.
    
    O(n log n) instead of O(n) merge-sort merge step.
    Also uses bubble sort instead of built-in sorted().
    """
    combined = list_a + list_b
    
    # Bubble sort instead of sorted()
    for i in range(len(combined)):
        for j in range(len(combined) - 1):
            val_j = combined[j].get(sort_key, '')
            val_j1 = combined[j + 1].get(sort_key, '')
            if str(val_j) > str(val_j1):
                combined[j], combined[j + 1] = combined[j + 1], combined[j]
    
    return combined


def group_tasks_by_date(tasks):
    """Group tasks by creation date — multiple inefficiencies.
    
    1. Iterates tasks multiple times
    2. String parsing dates in inner loop
    3. Sorts each group separately
    """
    # First pass: collect all dates
    all_dates = []
    for task in tasks:
        date_str = task.get('created_at', '')[:10]  # YYYY-MM-DD
        if date_str and date_str not in all_dates:
            all_dates.append(date_str)
    
    # Sort dates — using bubble sort again
    for i in range(len(all_dates)):
        for j in range(len(all_dates) - 1):
            if all_dates[j] > all_dates[j + 1]:
                all_dates[j], all_dates[j + 1] = all_dates[j + 1], all_dates[j]
    
    # Second pass: group tasks by date — O(n*d) where d = number of dates
    grouped = {}
    for date in all_dates:
        grouped[date] = []
        for task in tasks:  # Re-iterating all tasks for each date
            task_date = task.get('created_at', '')[:10]
            if task_date == date:
                grouped[date].append(task)
    
    return grouped


def calculate_team_velocity(sprints):
    """Calculate team velocity metrics — unnecessary recomputation.
    
    Computes averages multiple times over the same data.
    """
    if not sprints:
        return {}
    
    # Compute total points — iterate once
    total_points = 0
    for sprint in sprints:
        total_points += sprint.get('completed_points', 0)
    
    # Compute average — iterate AGAIN (could use total_points / len)
    point_sum = 0
    for sprint in sprints:
        point_sum += sprint.get('completed_points', 0)
    average = point_sum / len(sprints)
    
    # Compute max — iterate AGAIN
    max_points = 0
    for sprint in sprints:
        if sprint.get('completed_points', 0) > max_points:
            max_points = sprint.get('completed_points', 0)
    
    # Compute min — iterate AGAIN
    min_points = float('inf')
    for sprint in sprints:
        if sprint.get('completed_points', 0) < min_points:
            min_points = sprint.get('completed_points', 0)
    
    # Compute variance — iterate AGAIN
    variance_sum = 0
    for sprint in sprints:
        diff = sprint.get('completed_points', 0) - average
        variance_sum += diff * diff
    variance = variance_sum / len(sprints)
    
    # Compute trend — iterate AGAIN
    recent = sprints[-3:]  # Last 3 sprints
    recent_avg = sum(s.get('completed_points', 0) for s in recent) / len(recent) if recent else 0
    
    return {
        "total_points": total_points,
        "average": average,
        "max": max_points,
        "min": min_points,
        "variance": variance,
        "recent_average": recent_avg,
        "sprint_count": len(sprints)
    }


# ─── String Processing (Needs Unit Tests) ────────────────────────────────────

def sanitize_input(text):
    """Sanitize user input — INCOMPLETE sanitization.
    
    Needs unit tests to verify:
    - HTML tags are stripped
    - SQL keywords handled
    - Special characters escaped
    - Unicode handling
    - Empty/None input
    - Very long strings
    """
    if not text:
        return ""
    
    # Only removes <script> tags — doesn't handle other HTML
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)
    
    # Doesn't handle: <img onerror=...>, <div onload=...>, etc.
    # Doesn't handle SQL injection at all
    # Doesn't handle null bytes
    
    return text.strip()


def parse_date_flexible(date_string):
    """Parse dates in multiple formats — needs comprehensive tests.
    
    Should handle: YYYY-MM-DD, DD/MM/YYYY, MM-DD-YYYY, 
    "yesterday", "today", "next week", ISO 8601, etc.
    """
    if not date_string:
        return None
    
    date_string = date_string.strip()
    
    # Handle relative dates
    if date_string.lower() == 'today':
        return datetime.now().date()
    elif date_string.lower() == 'yesterday':
        return (datetime.now() - timedelta(days=1)).date()
    elif date_string.lower() == 'tomorrow':
        return (datetime.now() + timedelta(days=1)).date()
    
    # Try parsing different formats
    formats = [
        '%Y-%m-%d',
        '%d/%m/%Y',
        '%m-%d-%Y',
        '%Y-%m-%dT%H:%M:%S',
        '%Y-%m-%dT%H:%M:%SZ',
        '%d %b %Y',
        '%B %d, %Y',
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_string, fmt).date()
        except ValueError:
            continue
    
    return None  # Returns None on failure — caller must handle


def extract_tags(text):
    """Extract hashtags and @mentions from text — needs tests.
    
    Expected behavior:
    - "#bug" → tag "bug"
    - "@john" → mention "john"  
    - "email@test.com" → NOT a mention
    - "#123" → NOT a tag (pure numbers)
    - "#multi-word" → tag "multi-word"
    """
    tags = re.findall(r'(?<!\S)#([a-zA-Z][a-zA-Z0-9_-]*)', text)
    mentions = re.findall(r'(?<!\S)@([a-zA-Z][a-zA-Z0-9_]*)', text)
    
    return {"tags": tags, "mentions": mentions}


def format_duration(seconds):
    """Format seconds into human-readable duration — needs edge case tests.
    
    Expected: 
    - 0 → "0 seconds"
    - 60 → "1 minute"
    - 3661 → "1 hour, 1 minute, 1 second"
    - 86400 → "1 day"
    - negative → ???
    - very large → ???
    """
    if seconds < 0:
        return "Invalid duration"
    
    if seconds == 0:
        return "0 seconds"
    
    days = int(seconds // 86400)
    hours = int((seconds % 86400) // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    
    parts = []
    if days > 0:
        parts.append(f"{days} day{'s' if days != 1 else ''}")
    if hours > 0:
        parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if minutes > 0:
        parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
    if secs > 0:
        parts.append(f"{secs} second{'s' if secs != 1 else ''}")
    
    return ", ".join(parts)


def calculate_task_completion_rate(tasks):
    """Calculate completion rate percentage — needs tests for edge cases.
    
    Edge cases:
    - Empty list → 0%
    - All done → 100%
    - Mixed statuses
    - Invalid status values
    """
    if not tasks:
        return 0.0
    
    done_count = sum(1 for t in tasks if t.get('status') == 'done')
    return round((done_count / len(tasks)) * 100, 2)


def validate_task_data(data):
    """Validate task creation data — needs comprehensive tests.
    
    Should validate:
    - Title is required and 1-200 chars
    - Priority is 0-10
    - Due date is in the future
    - Status is valid enum value
    - Tags format is correct
    """
    errors = []
    
    title = data.get('title', '')
    if not title:
        errors.append("Title is required")
    elif len(title) > 200:
        errors.append("Title must be 200 characters or less")
    
    priority = data.get('priority', 0)
    if not isinstance(priority, int) or priority < 0 or priority > 10:
        errors.append("Priority must be an integer between 0 and 10")
    
    due_date = data.get('due_date')
    if due_date:
        parsed = parse_date_flexible(due_date)
        if not parsed:
            errors.append("Invalid date format")
    
    valid_statuses = ['pending', 'active', 'done', 'blocked', 'cancelled']
    status = data.get('status', 'pending')
    if status not in valid_statuses:
        errors.append(f"Status must be one of: {', '.join(valid_statuses)}")
    
    return {"valid": len(errors) == 0, "errors": errors}


# ─── CSV Export (Performance + Testing) ───────────────────────────────────────

def export_tasks_to_csv(tasks):
    """Export tasks to CSV string — string concatenation anti-pattern.
    
    Uses += in a loop for string building instead of csv.writer or io.StringIO.
    """
    csv_output = "id,title,status,priority,assigned_to,due_date,created_at\n"
    
    for task in tasks:
        # String concatenation in loop — O(n²) for large datasets
        row = f"{task.get('id', '')},{task.get('title', '').replace(',', ';')},{task.get('status', '')},"
        row += f"{task.get('priority', 0)},{task.get('assigned_to', '')},{task.get('due_date', '')},"
        row += f"{task.get('created_at', '')}\n"
        csv_output += row
    
    return csv_output


def import_tasks_from_csv(csv_string):
    """Import tasks from CSV — no validation, no error handling.
    
    Needs tests for:
    - Valid CSV
    - Missing columns
    - Extra columns
    - Malformed rows
    - Unicode content
    - Very large files
    """
    tasks = []
    lines = csv_string.strip().split('\n')
    
    if len(lines) < 2:
        return tasks
    
    headers = lines[0].split(',')
    
    for line in lines[1:]:
        values = line.split(',')  # Doesn't handle quoted commas
        task = {}
        for i, header in enumerate(headers):
            if i < len(values):
                task[header.strip()] = values[i].strip()
        tasks.append(task)
    
    return tasks


# ─── Date Range Analysis (More O(n²)) ────────────────────────────────────────

def get_tasks_in_date_range(tasks, start_date, end_date):
    """Filter tasks by date range — parses date strings repeatedly.
    
    Parses the same date strings every time this function is called
    instead of storing pre-parsed dates.
    """
    result = []
    for task in tasks:
        date_str = task.get('created_at', '')[:10]
        if date_str:
            try:
                task_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                if start_date <= task_date <= end_date:
                    result.append(task)
            except ValueError:
                continue
    return result


def calculate_burndown(tasks, sprint_start, sprint_end):
    """Calculate sprint burndown data — very inefficient.
    
    For each day in the sprint, re-scans all tasks to count completions.
    O(days * tasks) instead of O(tasks) with pre-processing.
    """
    burndown = []
    current = sprint_start
    total_points = sum(t.get('points', 1) for t in tasks)
    
    while current <= sprint_end:
        # Re-scan ALL tasks for each day
        remaining = total_points
        for task in tasks:
            completed_date = task.get('completed_at', '')[:10] if task.get('completed_at') else ''
            if completed_date:
                try:
                    comp_date = datetime.strptime(completed_date, '%Y-%m-%d').date()
                    if comp_date <= current:
                        remaining -= task.get('points', 1)
                except ValueError:
                    pass
        
        burndown.append({
            "date": str(current),
            "remaining": max(0, remaining),
            "ideal": total_points * (1 - (current - sprint_start).days / max(1, (sprint_end - sprint_start).days))
        })
        current += timedelta(days=1)
    
    return burndown
