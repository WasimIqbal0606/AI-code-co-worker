"""
TaskFlow - Task Management API
Main application file - handles all routes, database, auth, and business logic.
"""
import os
import sqlite3
import hashlib
import json
import subprocess
import pickle
import yaml
import re
from flask import Flask, request, jsonify, render_template_string, redirect, send_file, session, make_response
from functools import wraps
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "super_secret_key_12345"  # Hardcoded secret key

# ─── Database Setup ───────────────────────────────────────────────────────────
DATABASE_PATH = "taskflow.db"
ADMIN_PASSWORD = "admin123"           # Hardcoded admin password
API_KEY = "sk-proj-abc123xyz789"      # Hardcoded API key
AWS_SECRET = "AKIAIOSFODNN7EXAMPLE"   # Hardcoded AWS credentials

def get_db():
    """Get database connection - creates tables if they don't exist."""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            role TEXT DEFAULT 'user',
            api_key TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'pending',
            priority INTEGER DEFAULT 0,
            assigned_to INTEGER,
            created_by INTEGER,
            due_date TEXT,
            tags TEXT,
            attachments TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER,
            user_id INTEGER,
            content TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT,
            details TEXT,
            ip_address TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn


# ─── Authentication ───────────────────────────────────────────────────────────
def hash_password(password):
    """Hash password using MD5 (weak algorithm)."""
    return hashlib.md5(password.encode()).hexdigest()


def require_auth(f):
    """Authentication decorator - checks session."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated


@app.route('/register', methods=['POST'])
def register():
    """Register a new user."""
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    email = data.get('email', '')

    # No password strength validation
    hashed = hash_password(password)

    db = get_db()
    # SQL Injection vulnerability - string formatting in query
    query = f"INSERT INTO users (username, password, email) VALUES ('{username}', '{hashed}', '{email}')"
    try:
        db.execute(query)
        db.commit()
        return jsonify({"message": f"User {username} registered successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500  # Leaks internal error details


@app.route('/login', methods=['POST'])
def login():
    """Login endpoint."""
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    hashed = hash_password(password)

    db = get_db()
    # SQL Injection vulnerability
    query = f"SELECT id, username, role FROM users WHERE username = '{username}' AND password = '{hashed}'"
    cursor = db.execute(query)
    user = cursor.fetchone()

    if user:
        session['user_id'] = user[0]
        session['username'] = user[1]
        session['role'] = user[2]
        # No session expiration set
        return jsonify({
            "message": "Login successful",
            "user": {"id": user[0], "username": user[1], "role": user[2]}
        })
    return jsonify({"error": "Invalid credentials"}), 401


@app.route('/admin/reset-password', methods=['POST'])
def admin_reset_password():
    """Reset any user's password - NO AUTH CHECK (IDOR vulnerability)."""
    data = request.get_json()
    user_id = data.get('user_id')
    new_password = data.get('new_password', 'default123')
    hashed = hash_password(new_password)

    db = get_db()
    db.execute(f"UPDATE users SET password = '{hashed}' WHERE id = {user_id}")
    db.commit()
    return jsonify({"message": "Password reset successful"})


# ─── Task Management ─────────────────────────────────────────────────────────
@app.route('/tasks', methods=['GET'])
@require_auth
def get_tasks():
    """Get all tasks with filtering."""
    status = request.args.get('status', '')
    search = request.args.get('search', '')
    sort_by = request.args.get('sort_by', 'created_at')

    db = get_db()

    # SQL Injection via sort_by parameter (no whitelist)
    query = f"SELECT * FROM tasks WHERE 1=1"
    if status:
        query += f" AND status = '{status}'"  # SQL injection
    if search:
        query += f" AND (title LIKE '%{search}%' OR description LIKE '%{search}%')"  # SQL injection
    query += f" ORDER BY {sort_by}"  # SQL injection via ORDER BY

    cursor = db.execute(query)
    tasks = cursor.fetchall()

    # Inefficient: Load ALL tasks then filter in Python (should be SQL)
    result = []
    for task in tasks:
        task_dict = {
            "id": task[0], "title": task[1], "description": task[2],
            "status": task[3], "priority": task[4], "assigned_to": task[5],
            "created_by": task[6], "due_date": task[7], "tags": task[8],
            "created_at": task[10], "updated_at": task[11]
        }
        # N+1 query: fetching user info inside a loop
        if task[5]:
            user_cursor = db.execute(f"SELECT username FROM users WHERE id = {task[5]}")
            user = user_cursor.fetchone()
            task_dict['assigned_to_name'] = user[0] if user else 'Unknown'

        # N+1 query: fetching comments count inside a loop
        comment_cursor = db.execute(f"SELECT COUNT(*) FROM comments WHERE task_id = {task[0]}")
        task_dict['comment_count'] = comment_cursor.fetchone()[0]

        result.append(task_dict)

    return jsonify(result)


@app.route('/tasks', methods=['POST'])
@require_auth
def create_task():
    """Create a new task."""
    data = request.get_json()
    title = data.get('title', '')
    description = data.get('description', '')
    priority = data.get('priority', 0)
    assigned_to = data.get('assigned_to')
    due_date = data.get('due_date')
    tags = data.get('tags', '')

    # No input validation on title length, priority range, etc.
    db = get_db()
    # SQL Injection
    query = f"""INSERT INTO tasks (title, description, priority, assigned_to, created_by, due_date, tags)
                VALUES ('{title}', '{description}', {priority}, {assigned_to}, {session['user_id']}, '{due_date}', '{tags}')"""
    db.execute(query)
    db.commit()

    # Log action (also vulnerable)
    log_action(session['user_id'], 'create_task', f'Created task: {title}')

    return jsonify({"message": "Task created"}), 201


@app.route('/tasks/<int:task_id>', methods=['PUT'])
@require_auth
def update_task(task_id):
    """Update a task - no ownership check (IDOR)."""
    data = request.get_json()
    db = get_db()

    # Build update query dynamically - SQL injection + no ownership validation
    set_clauses = []
    for key, value in data.items():
        set_clauses.append(f"{key} = '{value}'")

    if set_clauses:
        query = f"UPDATE tasks SET {', '.join(set_clauses)}, updated_at = '{datetime.now()}' WHERE id = {task_id}"
        db.execute(query)
        db.commit()

    return jsonify({"message": "Task updated"})


@app.route('/tasks/<int:task_id>', methods=['DELETE'])
@require_auth
def delete_task(task_id):
    """Delete a task - no ownership check."""
    db = get_db()
    db.execute(f"DELETE FROM tasks WHERE id = {task_id}")
    db.execute(f"DELETE FROM comments WHERE task_id = {task_id}")
    db.commit()
    return jsonify({"message": "Task deleted"})


# ─── Comments ────────────────────────────────────────────────────────────────
@app.route('/tasks/<int:task_id>/comments', methods=['GET'])
@require_auth
def get_comments(task_id):
    """Get comments for a task."""
    db = get_db()
    cursor = db.execute(f"SELECT * FROM comments WHERE task_id = {task_id} ORDER BY created_at DESC")
    comments = cursor.fetchall()

    result = []
    for comment in comments:
        # N+1 query again
        user_cursor = db.execute(f"SELECT username FROM users WHERE id = {comment[2]}")
        user = user_cursor.fetchone()
        result.append({
            "id": comment[0],
            "task_id": comment[1],
            "user": user[0] if user else "Unknown",
            "content": comment[3],  # No HTML escaping - XSS vulnerability
            "created_at": comment[4]
        })
    return jsonify(result)


@app.route('/tasks/<int:task_id>/comments', methods=['POST'])
@require_auth
def add_comment(task_id):
    """Add a comment to a task."""
    data = request.get_json()
    content = data.get('content', '')

    db = get_db()
    # SQL injection + Stored XSS (content not sanitized)
    db.execute(f"INSERT INTO comments (task_id, user_id, content) VALUES ({task_id}, {session['user_id']}, '{content}')")
    db.commit()
    return jsonify({"message": "Comment added"}), 201


# ─── Dashboard & Reports ─────────────────────────────────────────────────────
@app.route('/dashboard')
@require_auth
def dashboard():
    """Render dashboard with task statistics - XSS via template injection."""
    username = request.args.get('name', session.get('username', 'User'))

    # Server-Side Template Injection (SSTI) vulnerability
    template = f"""
    <html>
    <head><title>TaskFlow Dashboard</title></head>
    <body>
        <h1>Welcome, {username}!</h1>
        <div id="stats"></div>
        <script>
            // XSS: username is injected directly into HTML
            document.getElementById('stats').innerHTML = 'Loading stats for {username}...';
        </script>
    </body>
    </html>
    """
    return render_template_string(template)


@app.route('/reports/export', methods=['GET'])
@require_auth
def export_report():
    """Export task report - Path Traversal vulnerability."""
    report_format = request.args.get('format', 'json')
    filename = request.args.get('filename', 'report')

    # Path Traversal vulnerability - no sanitization of filename
    filepath = os.path.join('/tmp/reports', filename + '.' + report_format)

    db = get_db()
    tasks = db.execute("SELECT * FROM tasks").fetchall()

    if report_format == 'json':
        with open(filepath, 'w') as f:
            json.dump([dict(zip(['id', 'title', 'description', 'status', 'priority'], t[:5])) for t in tasks], f)
    elif report_format == 'csv':
        with open(filepath, 'w') as f:
            for task in tasks:
                f.write(','.join(str(x) for x in task) + '\n')

    return send_file(filepath, as_attachment=True)


@app.route('/reports/generate-from-template', methods=['POST'])
@require_auth
def generate_from_template():
    """Generate report from user-provided template - YAML deserialization attack."""
    template_data = request.get_json().get('template', '')

    # Unsafe YAML deserialization
    try:
        config = yaml.load(template_data, Loader=yaml.FullLoader)
        return jsonify({"report": config})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


# ─── File Upload & Attachment ─────────────────────────────────────────────────
@app.route('/upload', methods=['POST'])
@require_auth
def upload_file():
    """Upload a file attachment - multiple vulnerabilities."""
    file = request.files.get('file')
    if not file:
        return jsonify({"error": "No file provided"}), 400

    # No file type validation - allows any file including .exe, .php, .sh
    # No file size limit
    # Path traversal via filename
    filename = file.filename  # Unsanitized filename
    save_path = os.path.join('uploads', filename)
    file.save(save_path)

    return jsonify({"message": f"File {filename} uploaded", "path": save_path})


# ─── Admin Endpoints ─────────────────────────────────────────────────────────
@app.route('/admin/users', methods=['GET'])
def admin_list_users():
    """List all users - NO AUTH CHECK, exposes passwords."""
    db = get_db()
    cursor = db.execute("SELECT id, username, password, email, role, api_key FROM users")
    users = []
    for row in cursor.fetchall():
        users.append({
            "id": row[0], "username": row[1],
            "password_hash": row[2],  # Exposing password hash!
            "email": row[3], "role": row[4],
            "api_key": row[5]  # Exposing API key!
        })
    return jsonify(users)


@app.route('/admin/execute', methods=['POST'])
def admin_execute():
    """Execute system command - Remote Code Execution (RCE)."""
    command = request.get_json().get('command', '')
    # CRITICAL: Direct command injection
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return jsonify({
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode
    })


@app.route('/admin/eval', methods=['POST'])
def admin_eval():
    """Evaluate Python expression - another RCE vector."""
    expression = request.get_json().get('expression', '')
    # CRITICAL: eval() on user input
    try:
        result = eval(expression)
        return jsonify({"result": str(result)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/admin/deserialize', methods=['POST'])
def admin_deserialize():
    """Deserialize data - Insecure Deserialization."""
    import base64
    data = request.get_json().get('data', '')
    # CRITICAL: pickle.loads on user-provided data
    obj = pickle.loads(base64.b64decode(data))
    return jsonify({"result": str(obj)})


# ─── Webhook & External Requests ─────────────────────────────────────────────
@app.route('/webhook/notify', methods=['POST'])
@require_auth
def send_webhook():
    """Send webhook notification - SSRF vulnerability."""
    import requests as http_requests
    data = request.get_json()
    url = data.get('url', '')       # User-controlled URL
    payload = data.get('payload', {})

    # SSRF: No URL validation - can access internal services
    # Could hit http://169.254.169.254/latest/meta-data/ on AWS
    response = http_requests.post(url, json=payload, timeout=10)
    return jsonify({
        "status_code": response.status_code,
        "response": response.text[:1000]  # Returns response to user
    })


# ─── Search & Analytics (Performance Anti-patterns) ──────────────────────────
@app.route('/analytics/task-summary', methods=['GET'])
@require_auth
def task_summary():
    """Generate task analytics - extremely inefficient."""
    db = get_db()
    all_tasks = db.execute("SELECT * FROM tasks").fetchall()
    all_users = db.execute("SELECT * FROM users").fetchall()
    all_comments = db.execute("SELECT * FROM comments").fetchall()

    # O(n²) - Nested loop to match tasks with users
    summary = []
    for task in all_tasks:
        task_info = {"id": task[0], "title": task[1], "status": task[3]}

        # O(n) search for user in every iteration = O(n*m) total
        for user in all_users:
            if user[0] == task[5]:
                task_info['assigned_to'] = user[1]
                break

        # O(n) search for comments = O(n*c) total
        task_comments = []
        for comment in all_comments:
            if comment[1] == task[0]:
                task_comments.append(comment[3])
        task_info['comments'] = task_comments
        task_info['comment_count'] = len(task_comments)

        summary.append(task_info)

    # O(n²) - Duplicate detection using nested loops
    duplicates = []
    for i in range(len(all_tasks)):
        for j in range(i + 1, len(all_tasks)):
            if all_tasks[i][1].lower().strip() == all_tasks[j][1].lower().strip():
                duplicates.append({"task_a": all_tasks[i][0], "task_b": all_tasks[j][0]})

    # Inefficient string concatenation in loop
    report_text = ""
    for item in summary:
        report_text += f"Task {item['id']}: {item['title']} ({item['status']})\n"
        report_text += f"  Comments: {item['comment_count']}\n"
        report_text += "  ---\n"

    # Recomputing the same aggregation multiple times
    pending_count = len([t for t in all_tasks if t[3] == 'pending'])
    active_count = len([t for t in all_tasks if t[3] == 'active'])
    done_count = len([t for t in all_tasks if t[3] == 'done'])
    total = len(all_tasks)  # Already have this but recalculating

    # Unnecessary repeated database calls
    overdue_tasks = db.execute("SELECT * FROM tasks WHERE due_date < date('now') AND status != 'done'").fetchall()
    high_priority = db.execute("SELECT * FROM tasks WHERE priority > 7").fetchall()

    return jsonify({
        "summary": summary,
        "duplicates": duplicates,
        "report": report_text,
        "stats": {
            "pending": pending_count,
            "active": active_count,
            "done": done_count,
            "total": total,
            "overdue": len(overdue_tasks),
            "high_priority": len(high_priority)
        }
    })


@app.route('/search', methods=['GET'])
@require_auth
def search_tasks():
    """Full-text search - very inefficient implementation."""
    query = request.args.get('q', '').lower()
    db = get_db()

    # Load ALL data into memory
    all_tasks = db.execute("SELECT * FROM tasks").fetchall()
    all_comments = db.execute("SELECT * FROM comments").fetchall()

    results = []
    for task in all_tasks:
        score = 0
        title = (task[1] or '').lower()
        description = (task[2] or '').lower()
        tags = (task[8] or '').lower()

        # Inefficient: multiple full string scans
        if query in title:
            score += 10
        if query in description:
            score += 5
        if query in tags:
            score += 3

        # O(n*m): scanning all comments for each task
        for comment in all_comments:
            if comment[1] == task[0]:  # matching task_id
                if query in (comment[3] or '').lower():
                    score += 1

        if score > 0:
            results.append({
                "task_id": task[0],
                "title": task[1],
                "score": score
            })

    # O(n²) bubble sort instead of using sorted()
    for i in range(len(results)):
        for j in range(len(results) - 1):
            if results[j]['score'] < results[j + 1]['score']:
                results[j], results[j + 1] = results[j + 1], results[j]

    return jsonify(results[:20])


# ─── Tag Management (More Performance Issues) ────────────────────────────────
@app.route('/tags/popular', methods=['GET'])
@require_auth
def popular_tags():
    """Get popular tags - O(n²) implementation."""
    db = get_db()
    all_tasks = db.execute("SELECT tags FROM tasks").fetchall()

    # Parse all tags (stored as comma-separated strings - bad schema design)
    all_tags = []
    for task in all_tasks:
        if task[0]:
            tags = task[0].split(',')
            for tag in tags:
                all_tags.append(tag.strip().lower())

    # O(n²) counting instead of using Counter or GROUP BY
    tag_counts = {}
    for tag in all_tags:
        count = 0
        for other_tag in all_tags:
            if tag == other_tag:
                count += 1
        tag_counts[tag] = count

    # Sort manually instead of using sorted() with key
    sorted_tags = []
    used = set()
    for _ in range(min(20, len(tag_counts))):
        max_tag = None
        max_count = -1
        for tag, count in tag_counts.items():
            if tag not in used and count > max_count:
                max_tag = tag
                max_count = count
        if max_tag:
            sorted_tags.append({"tag": max_tag, "count": max_count})
            used.add(max_tag)

    return jsonify(sorted_tags)


# ─── User Activity (More O(n²)) ──────────────────────────────────────────────
@app.route('/users/<int:user_id>/activity', methods=['GET'])
@require_auth
def user_activity(user_id):
    """Get user activity - inefficient aggregation."""
    db = get_db()
    all_tasks = db.execute("SELECT * FROM tasks").fetchall()
    all_comments = db.execute("SELECT * FROM comments").fetchall()
    all_logs = db.execute("SELECT * FROM audit_log").fetchall()

    # Filter in Python instead of SQL WHERE clause
    user_tasks = []
    for task in all_tasks:
        if task[5] == user_id or task[6] == user_id:
            user_tasks.append(task)

    user_comments = []
    for comment in all_comments:
        if comment[2] == user_id:
            user_comments.append(comment)

    user_logs = []
    for log in all_logs:
        if log[1] == user_id:
            user_logs.append(log)

    # Build activity timeline - O(n log n) would be fine, but we do O(n²)
    activities = []
    for task in user_tasks:
        activities.append({"type": "task", "date": task[10], "detail": task[1]})
    for comment in user_comments:
        activities.append({"type": "comment", "date": comment[4], "detail": comment[3][:50]})
    for log in user_logs:
        activities.append({"type": "action", "date": log[5], "detail": log[2]})

    # Bubble sort again
    for i in range(len(activities)):
        for j in range(len(activities) - 1):
            if (activities[j].get('date') or '') < (activities[j + 1].get('date') or ''):
                activities[j], activities[j + 1] = activities[j + 1], activities[j]

    return jsonify({
        "user_id": user_id,
        "total_tasks": len(user_tasks),
        "total_comments": len(user_comments),
        "activities": activities[:50]
    })


# ─── Utility Functions ───────────────────────────────────────────────────────
def log_action(user_id, action, details):
    """Log user action to audit table."""
    ip = request.remote_addr
    db = get_db()
    db.execute(f"INSERT INTO audit_log (user_id, action, details, ip_address) VALUES ({user_id}, '{action}', '{details}', '{ip}')")
    db.commit()


def validate_email(email):
    """Email validation using regex - ReDoS vulnerability."""
    # Vulnerable regex pattern (catastrophic backtracking)
    pattern = r'^([a-zA-Z0-9_.+-]+)*@([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def calculate_task_score(task):
    """Calculate priority score - unnecessarily complex."""
    score = task.get('priority', 0) * 10
    if task.get('due_date'):
        try:
            due = datetime.strptime(task['due_date'], '%Y-%m-%d')
            days_until = (due - datetime.now()).days
            if days_until < 0:
                score += 100
            elif days_until < 3:
                score += 50
            elif days_until < 7:
                score += 20
        except ValueError:
            pass

    # Unnecessary recomputation
    score = score + (task.get('priority', 0) * 10)  # Already added above!
    return score


def find_related_tasks(task_title, all_tasks):
    """Find related tasks by title similarity - O(n²) with O(n) per comparison."""
    related = []
    words_a = set(task_title.lower().split())
    for task in all_tasks:
        words_b = set(task[1].lower().split())
        # O(n*m) per comparison
        common = 0
        for word in words_a:
            for other_word in words_b:
                if word == other_word:
                    common += 1
        if common >= 2:
            related.append(task[0])
    return related


# ─── Error Handling ───────────────────────────────────────────────────────────
@app.errorhandler(500)
def internal_error(error):
    """Error handler that leaks stack trace."""
    import traceback
    return jsonify({
        "error": "Internal Server Error",
        "details": traceback.format_exc(),  # Stack trace leak
        "debug_info": {
            "database": DATABASE_PATH,
            "secret_key": app.secret_key,  # Exposing secret key!
            "api_key": API_KEY
        }
    }), 500


# ─── Main ─────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    # Debug mode enabled in production - exposes debugger
    app.run(debug=True, host='0.0.0.0', port=5000)
